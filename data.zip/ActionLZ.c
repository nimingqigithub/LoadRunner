ActionLZ()
{

	web_url("success.txt", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t29.inf", 
		LAST);

	web_url("success.txt_2", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t30.inf", 
		LAST);

	lr_think_time(11);

	web_url("success.txt_3", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t31.inf", 
		LAST);

	web_url("success.txt_4", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t32.inf", 
		LAST);

	web_url("success.txt_5", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t33.inf", 
		LAST);

	web_url("success.txt_6", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t34.inf", 
		LAST);

	web_url("Tips", 
		"URL=http://192.168.5.200:8034/GisqRealEstate-Explorer/Tips?login&username=zscs&flag=circle&callback=tipsResultCircle&_=1511496857091", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=http://192.168.5.200:8082/GisqPlatformExplorer/a?login", 
		"Snapshot=t35.inf", 
		LAST);

	lr_think_time(31);

	web_url("success.txt_7", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t36.inf", 
		LAST);

	web_url("success.txt_8", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t37.inf", 
		LAST);

	web_url("success.txt_9", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t38.inf", 
		LAST);

	web_url("replace_url.js", 
		"URL=http://img.function.liebao.cn/json/replace_url.js?1511496873637", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t39.inf", 
		LAST);

	web_add_cookie("infoc_client_uuid=c63f42af60f8f94e01984402de61426d; DOMAIN=www.liebao.cn");

	web_url("textlink15.js", 
		"URL=http://www.liebao.cn/newtab/textlink15.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t40.inf", 
		LAST);

	web_url("versionCondition.js", 
		"URL=http://img.function.liebao.cn/json/versionCondition.js?t=419860242.68333334", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t41.inf", 
		LAST);

	web_url("bgData3.js", 
		"URL=http://www.liebao.cn/newtab/bgData3.js?t=419860", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t42.inf", 
		LAST);

	web_url("city.json", 
		"URL=http://www.liebao.cn/newtab/weather/js/city.json", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t43.inf", 
		LAST);

	web_url("mainV3.js", 
		"URL=http://www.liebao.cn/newtab/weather/js/mainV3.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t44.inf", 
		LAST);

	web_url("rain-small.jpg", 
		"URL=http://www.liebao.cn/newtab/background/rain-small.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=", 
		"Snapshot=t45.inf", 
		LAST);

	web_url("light-small.jpg", 
		"URL=http://www.liebao.cn/newtab/background/light-small.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=", 
		"Snapshot=t46.inf", 
		LAST);

	web_add_cookie("PSTM=1506144047; DOMAIN=unionsug.baidu.com");

	web_add_cookie("BAIDUID=AEA94DF6018FF836877FE8E74768F747:FG=1; DOMAIN=unionsug.baidu.com");

	web_add_cookie("__cfduid=d3e34b51c0ee8bad733b9483f3b3c287c1509067072; DOMAIN=unionsug.baidu.com");

	web_add_cookie("BIDUPSID=C22C82A36CEA25350006F692176BE181; DOMAIN=unionsug.baidu.com");

	web_add_cookie("BDRCVFR[4Zjqyl1bxbt]=aeXf-1x8UdYcs; DOMAIN=unionsug.baidu.com");

	web_add_cookie("PSINO=5; DOMAIN=unionsug.baidu.com");

	web_add_cookie("H_PS_PSSID=1467_19033_21106_25178; DOMAIN=unionsug.baidu.com");

	web_add_cookie("BDORZ=FFFB88E999055A3F8A630C64834BD6D0; DOMAIN=unionsug.baidu.com");

	web_url("su", 
		"URL=http://unionsug.baidu.com/su?wd=%20&p=3&cb=window.baidu.sug&ie=UTF-8&t=1511496876030", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=", 
		"Snapshot=t47.inf", 
		LAST);

	web_url("su_2", 
		"URL=http://unionsug.baidu.com/su?wd=%E5%8D%8E%E4%B8%BA%E4%BA%91&p=3&cb=window.baidu.sug&ie=UTF-8&t=1511496877202", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=", 
		"Snapshot=t48.inf", 
		LAST);

	lr_think_time(20);

	web_url("success.txt_10", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t49.inf", 
		LAST);

	web_url("success.txt_11", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t50.inf", 
		LAST);

	web_url("success.txt_12", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t51.inf", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_cookie("PSTM=1506144047; DOMAIN=www.baidu.com");

	web_add_cookie("BAIDUID=AEA94DF6018FF836877FE8E74768F747:FG=1; DOMAIN=www.baidu.com");

	web_add_cookie("__cfduid=d3e34b51c0ee8bad733b9483f3b3c287c1509067072; DOMAIN=www.baidu.com");

	web_add_cookie("sug=3; DOMAIN=www.baidu.com");

	web_add_cookie("sugstore=1; DOMAIN=www.baidu.com");

	web_add_cookie("ORIGIN=0; DOMAIN=www.baidu.com");

	web_add_cookie("bdime=0; DOMAIN=www.baidu.com");

	web_add_cookie("BIDUPSID=C22C82A36CEA25350006F692176BE181; DOMAIN=www.baidu.com");

	web_add_cookie("ispeed_lsm=0; DOMAIN=www.baidu.com");

	web_add_cookie("BDRCVFR[4Zjqyl1bxbt]=aeXf-1x8UdYcs; DOMAIN=www.baidu.com");

	web_add_cookie("BD_HOME=0; DOMAIN=www.baidu.com");

	web_add_cookie("BD_UPN=16314753; DOMAIN=www.baidu.com");

	web_add_cookie("BD_CK_SAM=1; DOMAIN=www.baidu.com");

	web_add_cookie("PSINO=5; DOMAIN=www.baidu.com");

	web_add_cookie("H_PS_PSSID=1467_19033_21106_25178; DOMAIN=www.baidu.com");

	web_add_cookie("BDORZ=FFFB88E999055A3F8A630C64834BD6D0; DOMAIN=www.baidu.com");

	web_add_cookie("BDSVRTM=0; DOMAIN=www.baidu.com");

	web_url("baidu", 
		"URL=https://www.baidu.com/baidu?word=%E5%8D%8E%E4%B8%BA%E4%BA%91&tn=98012088_3_dg&ch=12&ie=utf-8", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t52.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("index.php", 
		"URL=https://www.baidu.com/index.php?tn=98012088_3_dg", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t53.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("success.txt_13", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t54.inf", 
		LAST);

	web_url("success.txt_14", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t55.inf", 
		LAST);

	web_url("success.txt_15", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t56.inf", 
		LAST);

	web_url("success.txt_16", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t57.inf", 
		LAST);

	web_url("success.txt_17", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t58.inf", 
		LAST);

	web_url("success.txt_18", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t59.inf", 
		LAST);

	web_concurrent_end(NULL);

	return 0;
}